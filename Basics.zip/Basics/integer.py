num = 10 # integer
print(type(num)) # prints type info for variable num
