# Python example, lets talk favorite animals
# part of 'Variables' example https://www.w3schools.com/programming/prog_variables.php

favAnimal = 'bees'
count = 12

print('I like', favAnimal, 'I have', count, 'of them')

